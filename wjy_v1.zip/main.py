import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

# 设置matplotlib支持中文字体
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False


def main():
    # 读取Excel文件
    df = pd.read_excel('wjy.xlsx')
    df.columns = df.columns.str.strip()
    # 过滤掉空白列、带有"误差"的列和以'Unnamed:'开头的列
    valid_cols = [col for col in df.columns if col and '误差' not in col and not col.startswith('Unnamed:')]
    df = df[valid_cols]
    # 显示所有可选年代表版本
    print('可选年代表版本：')
    for col in df.columns:
        print(col, end=' | ')
    print('\n')
    version = input('输入当前年代表版本：').strip()
    if version not in df.columns:
        print(f'未找到年代表版本：{version}')
        return
    # 直接提示输入自定义数字
    age = input('输入该版本对应的年代（可自定义输入数字）：').strip()
    # 智能查找：兼容数字和字符串
    def match_age(val):
        if pd.isna(val):
            return False
        try:
            return str(val).strip() == age or float(val) == float(age)
        except:
            return str(val).strip() == age
    match = df[df[version].apply(match_age)]
    iugs_col = None
    for col in df.columns:
        if "IUGS 2023.9" in col:
            iugs_col = col
            break
    if not iugs_col:
        print("未找到IUGS 2023.9列")
        return
    # 取前五列
    main_cols = list(df.columns[:5])
    # 取输入的列和IUGS 2023.9列
    special_cols = [version, iugs_col]
    # 合并并去重
    show_cols = []
    for col in main_cols + special_cols:
        if col not in show_cols:
            show_cols.append(col)
    # 只保留需要显示的列
    show_df = df[show_cols]
    if not match.empty:
        # 有完全匹配，按原逻辑输出
        for idx, row in match.iterrows():
            labels = ["宇", "界", "系", "统", "阶"]
            info = []
            for i, col in enumerate(labels):
                if col in df.columns:
                    info.append(f"{row.get(col, '')}{labels[i]}")
            iugs_value = row.get(iugs_col, "")
            print(f"{' '.join(info)} {iugs_value}")
            # 只显示表头和该行
            display_df = show_df.iloc[[idx]]
            display_df = pd.concat([show_df.head(0), display_df])
            print('\n只显示相关数据：')
            print(display_df.to_string(index=False))
            # 可视化：只显示这两行
            fig, ax = plt.subplots(figsize=(2*len(show_cols), 2))
            ax.axis('off')
            table = ax.table(cellText=display_df.values, colLabels=display_df.columns, loc='center', cellLoc='center')
            # 高亮数据行
            for j in range(len(display_df.columns)):
                table[(1, j)].set_facecolor('#FFFACD')
            # 高亮IUGS 2023.9列
            col_idx = display_df.columns.get_loc(iugs_col)
            table[(1, col_idx)].set_facecolor('#FF6347')
            # 高亮自定义输入的列
            input_col_idx = display_df.columns.get_loc(version)
            table[(1, input_col_idx)].set_facecolor('#90EE90')
            plt.title(f'仅显示相关数据（高亮：{iugs_col}={iugs_value}，{version}={age}）')
            plt.show()
            break  # 只显示第一个匹配
    else:
        # 没有完全匹配，尝试插值
        try:
            age_num = float(age)
        except:
            print(f'输入的年代"{age}"无法识别为数字，无法插值。')
            return
        # 只保留能转为数字的行
        version_numeric = pd.to_numeric(df[version], errors='coerce')
        valid_idx = version_numeric.notna()
        version_numeric = version_numeric[valid_idx]
        if version_numeric.empty:
            print(f'{version}列没有可用于插值的数字数据')
            return
        lower_idx = version_numeric[version_numeric <= age_num].idxmax() if (version_numeric <= age_num).any() else None
        upper_idx = version_numeric[version_numeric >= age_num].idxmin() if (version_numeric >= age_num).any() else None
        if lower_idx is None or upper_idx is None or lower_idx == upper_idx:
            print(f'无法找到合适的上下界进行插值')
            return
        lower_row = df.loc[lower_idx]
        upper_row = df.loc[upper_idx]
        lower_x = float(lower_row[version])
        upper_x = float(upper_row[version])
        lower_y = float(lower_row[iugs_col]) if pd.notna(lower_row[iugs_col]) else None
        upper_y = float(upper_row[iugs_col]) if pd.notna(upper_row[iugs_col]) else None
        if lower_y is None or upper_y is None:
            print('上下界的IUGS 2023.9数据缺失，无法插值')
            return
        ratio = (age_num - lower_x) / (upper_x - lower_x) if upper_x != lower_x else 0
        interp_value = lower_y + (upper_y - lower_y) * ratio
        # 查找IUGS 2023.9列中第一个大于插值值的最小值（区间上界）
        iugs_numeric = pd.to_numeric(df[iugs_col], errors='coerce')
        valid_iugs = iugs_numeric[iugs_numeric.notna() & (iugs_numeric > interp_value)]
        if valid_iugs.empty:
            print(f'IUGS 2023.9列中没有大于插值值{interp_value:.4f}的数据')
            return
        upper_value = valid_iugs.min()
        upper_idx = iugs_numeric[iugs_numeric == upper_value].index[0]
        upper_row = df.loc[upper_idx]
        # 输出替换后的结果
        labels = ["宇", "界", "系", "统", "阶"]
        info = []
        for i, col in enumerate(labels):
            if col in df.columns:
                info.append(f"{upper_row.get(col, '')}{labels[i]}")
        print(f"插值结果：{age_num} 在 {version} 列上下界 {lower_x} 和 {upper_x} 之间，对应{version}下的数字为：{age_num}，对应IUGS 2023.9插值为：{interp_value:.4f}，区间上界为：{upper_value}")
        print(f"对应行信息：{' '.join(info)} {upper_row[iugs_col]}")
        # 只显示表头和该行，临时替换输入列为自定义输入
        display_df = show_df.loc[[upper_idx]].copy()
        display_df.iloc[0, display_df.columns.get_loc(version)] = age_num
        display_df.iloc[0, display_df.columns.get_loc(iugs_col)] = interp_value  # 替换IUGS 2023.9为插值值
        display_df = pd.concat([show_df.head(0), display_df])
        print('\n只显示相关数据：')
        print(display_df.to_string(index=False))
        # 可视化：只显示这两行
        fig, ax = plt.subplots(figsize=(2*len(show_cols), 2))
        ax.axis('off')
        table = ax.table(cellText=display_df.values, colLabels=display_df.columns, loc='center', cellLoc='center')
        # 高亮数据行
        for j in range(len(display_df.columns)):
            table[(1, j)].set_facecolor('#FFFACD')
        # 高亮IUGS 2023.9列
        col_idx = display_df.columns.get_loc(iugs_col)
        table[(1, col_idx)].set_facecolor('#FF6347')
        # 高亮自定义输入的列
        input_col_idx = display_df.columns.get_loc(version)
        table[(1, input_col_idx)].set_facecolor('#90EE90')
        plt.title(f'区间上界：{interp_value:.4f} → {upper_value}，{version}下的数字为：{age_num}')
        plt.show()

if __name__ == "__main__":
    main() 