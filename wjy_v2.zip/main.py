import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import glob
import os

# 设置matplotlib支持中文字体
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False


def process_age_data(age, df, version, iugs_col, show_cols):
    """处理单个年代数据并返回结果DataFrame，如果无法处理则返回None"""
    print(f"\n--- 正在处理年代: {age} ---")
    def match_age_func(val):
        if pd.isna(val):
            return False
        try:
            return str(val).strip() == str(age).strip() or float(val) == float(age)
        except ValueError:
            return str(val).strip() == str(age).strip()
        except Exception:
            return False

    match = df[df[version].apply(match_age_func)]
    show_df_subset = df[show_cols]
    result_df = None

    if not match.empty:
        for idx, row in match.iterrows():
            labels = ["宇", "界", "系", "统", "阶"]
            info = []
            for i, col_label in enumerate(labels):
                if col_label in df.columns:
                    info.append(f"{row.get(col_label, '')}{labels[i]}")
            iugs_value = row.get(iugs_col, "")
            print(f"直接匹配: {' '.join(info)} {iugs_value}")
            display_df = show_df_subset.loc[[idx]].copy()
            result_df = display_df
            break 
    else:
        try:
            age_num = float(age)
        except ValueError:
            print(f'年代"{age}"无法识别为数字，无法插值。')
            return None

        version_numeric = pd.to_numeric(df[version], errors='coerce')
        valid_idx = version_numeric.notna()
        version_numeric_filtered = version_numeric[valid_idx]
        df_filtered = df[valid_idx]

        if version_numeric_filtered.empty:
            print(f'{version}列没有可用于插值的数字数据')
            return None

        lower_idx_series = version_numeric_filtered[version_numeric_filtered <= age_num]
        lower_idx = lower_idx_series.idxmax() if not lower_idx_series.empty else None
        upper_idx_series = version_numeric_filtered[version_numeric_filtered >= age_num]
        upper_idx = upper_idx_series.idxmin() if not upper_idx_series.empty else None

        if lower_idx is None or upper_idx is None:
            print(f'无法找到合适的上下界进行插值 (age_num={age_num})')
            return None
        
        if lower_idx == upper_idx and df_filtered.loc[lower_idx, version] == age_num:
            match_row_df = df_filtered.loc[[lower_idx]]
            labels = ["宇", "界", "系", "统", "阶"]
            info = []
            for i, col_label in enumerate(labels):
                if col_label in df.columns:
                    info.append(f"{match_row_df.iloc[0].get(col_label, '')}{labels[i]}")
            iugs_value = match_row_df.iloc[0].get(iugs_col, "")
            print(f"精确数值匹配: {' '.join(info)} {iugs_value}")
            result_df = show_df_subset.loc[[match_row_df.index[0]]].copy()
            result_df.loc[match_row_df.index[0], version] = age_num
            return result_df 
        elif lower_idx == upper_idx:
             print(f'无法找到合适的上下界进行插值，输入值 {age_num} 可能超出 {version} 列的数值范围。')
             return None

        lower_row = df_filtered.loc[lower_idx]
        upper_row = df_filtered.loc[upper_idx]
        lower_x = float(lower_row[version])
        upper_x = float(upper_row[version])
        lower_y_val = pd.to_numeric(lower_row[iugs_col], errors='coerce')
        upper_y_val = pd.to_numeric(upper_row[iugs_col], errors='coerce')

        if pd.isna(lower_y_val) or pd.isna(upper_y_val):
            print('上下界的IUGS 2023.9数据缺失或非数值，无法插值')
            return None
        
        lower_y = float(lower_y_val)
        upper_y = float(upper_y_val)
        ratio = (age_num - lower_x) / (upper_x - lower_x) if upper_x != lower_x else 0
        interp_value = lower_y + (upper_y - lower_y) * ratio
        
        iugs_numeric = pd.to_numeric(df[iugs_col], errors='coerce')
        valid_iugs_idx = iugs_numeric.notna()
        iugs_numeric_filtered = iugs_numeric[valid_iugs_idx]
        df_iugs_filtered = df[valid_iugs_idx]

        upper_value_candidates = iugs_numeric_filtered[iugs_numeric_filtered > interp_value]
        upper_row_for_table = None

        if upper_value_candidates.empty:
            print(f'IUGS 2023.9列中没有大于插值值{interp_value:.4f}的数据')
            if not iugs_numeric_filtered.empty:
                closest_value_idx = (iugs_numeric_filtered - interp_value).abs().idxmin()
                upper_row_for_table = df_iugs_filtered.loc[[closest_value_idx]]
                upper_value_display = upper_row_for_table.iloc[0][iugs_col]
                print(f"尝试使用IUGS 2023.9中最接近的值: {upper_value_display}")
            else:
                return None
        else:
            upper_value_final = upper_value_candidates.min()
            upper_idx_final_series = df_iugs_filtered[iugs_numeric_filtered == upper_value_final].index
            if upper_idx_final_series.empty:
                 print(f"无法找到值为 {upper_value_final} 的原始索引。")
                 return None
            upper_idx_final = upper_idx_final_series[0]
            upper_row_for_table = df_iugs_filtered.loc[[upper_idx_final]]
            upper_value_display = upper_value_final

        if upper_row_for_table is None:
            print("无法确定用于插值显示的对应行。")
            return None

        result_df = show_df_subset.loc[[upper_row_for_table.index[0]]].copy()
        result_df.loc[upper_row_for_table.index[0], version] = age_num 
        result_df.loc[upper_row_for_table.index[0], iugs_col] = interp_value 
        
        labels = ["宇", "界", "系", "统", "阶"]
        info_row = df.loc[upper_row_for_table.index[0]] 
        info = []
        for i, col_label in enumerate(labels):
            if col_label in df.columns:
                info.append(f"{info_row.get(col_label, '')}{labels[i]}")
        print(f"插值结果: {' '.join(info)} IUGS插值:{interp_value:.4f} (原上界IUGS:{upper_value_display}, 输入年代:{age_num})")
    
    return result_df

def main():
    # df 是主数据表，从 wjy.xlsx 读取
    df = pd.read_excel('wjy.xlsx') 
    df.columns = df.columns.str.strip()
    valid_cols = [col for col in df.columns if col and '误差' not in col and not col.startswith('Unnamed:')]
    df = df[valid_cols]

    print('可选年代表版本（来自主数据表 wjy.xlsx）：')
    for col in df.columns:
        print(col, end=' | ')
    print('\n')
    version = input('输入当前年代表版本（主数据表中的列名）：').strip()
    if version not in df.columns:
        print(f'未找到年代表版本：{version}')
        return

    # 查找 Excel 文件 (.xls or .xlsx) 作为年代数据源
    excel_files = glob.glob('*.xlsx') + glob.glob('*.xls')
    if not excel_files:
        print("当前目录下未找到Excel文件 (.xlsx 或 .xls)。")
        return
    
    print('\n可选的年代数据源Excel文件：')
    for i, file_path in enumerate(excel_files):
        print(f"{i + 1}. {file_path}")
    
    selected_excel_file_path = None
    while True:
        try:
            choice = int(input("请选择Excel文件编号：")) - 1
            if 0 <= choice < len(excel_files):
                selected_excel_file_path = excel_files[choice]
                break
            else:
                print("无效的选择，请输入列表中的编号。")
        except ValueError:
            print("无效输入，请输入数字编号。")

    ages_from_file = []
    try:
        # 读取选择的Excel文件
        source_excel_df = pd.read_excel(selected_excel_file_path)
        print(f"\n已读取文件: {selected_excel_file_path}")
        print("文件中的列名：")
        for col_name in source_excel_df.columns:
            print(col_name, end=' | ')
        print('\n')
        
        age_column_name = input("请输入包含年代数据的那一列的名称：").strip()
        if age_column_name not in source_excel_df.columns:
            print(f"在 {selected_excel_file_path} 中未找到列：{age_column_name}")
            return
            
        # 提取指定列的数据，跳过第一行（列名），转换为字符串并过滤空值
        # .tolist() 转换为列表，然后处理每个元素
        raw_ages = source_excel_df[age_column_name].astype(str).tolist()
        ages_from_file = [age_val.strip() for age_val in raw_ages if age_val.strip()] # 过滤空字符串

        if not ages_from_file:
            print(f"选择的Excel文件 {selected_excel_file_path} 的列 '{age_column_name}' 为空或不包含有效数据行。")
            return
        print(f"从 {selected_excel_file_path} 的 '{age_column_name}' 列读取的年代数据共 {len(ages_from_file)} 条: {', '.join(ages_from_file)}")
    except Exception as e:
        print(f"读取或处理Excel文件 {selected_excel_file_path} 失败：{e}")
        return

    iugs_col = None
    for col_name in df.columns:
        if "IUGS 2023.9" in col_name:
            iugs_col = col_name
            break
    if not iugs_col:
        print("在主数据表 wjy.xlsx 中未找到IUGS 2023.9列")
        return

    main_cols = list(df.columns[:5])
    special_cols = [version, iugs_col]
    show_cols_base = []
    for col_name in main_cols + special_cols:
        if col_name not in show_cols_base:
            show_cols_base.append(col_name)
    
    all_results_for_table = []
    for age_entry in ages_from_file:
        single_result_df = process_age_data(age_entry, df, version, iugs_col, show_cols_base)
        if single_result_df is not None:
            all_results_for_table.append(single_result_df)

    if not all_results_for_table:
        print("\n没有从Excel文件中处理得到任何有效数据行用于显示。")
        return

    final_table_df = pd.concat(all_results_for_table)
    display_columns = [col for col in show_cols_base if col in final_table_df.columns]
    final_table_df = final_table_df[display_columns]

    print("\n--- 所有年代数据的合并结果 ---")
    print(final_table_df.to_string(index=False))

    fig, ax = plt.subplots(figsize=(2 * len(final_table_df.columns), 0.5 * (len(final_table_df) + 1) ))
    ax.axis('off')
    table = ax.table(cellText=final_table_df.values, 
                     colLabels=final_table_df.columns, 
                     loc='center', 
                     cellLoc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.2)

    for i in range(len(final_table_df)):
        for j in range(len(final_table_df.columns)):
            table[(i + 1, j)].set_facecolor('#FFFACD') 
    
    if iugs_col in final_table_df.columns:
        col_idx_iugs = final_table_df.columns.get_loc(iugs_col)
        for i in range(len(final_table_df)):
            table[(i + 1, col_idx_iugs)].set_facecolor('#FF6347')

    if version in final_table_df.columns:
        input_col_idx = final_table_df.columns.get_loc(version)
        for i in range(len(final_table_df)):
            table[(i + 1, input_col_idx)].set_facecolor('#90EE90')
    
    plt.title(f'所有Excel输入年代的处理结果汇总 (共 {len(ages_from_file)} 条输入, 显示 {len(final_table_df)} 条结果)')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()